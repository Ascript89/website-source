//    AUTHOR    //

Assets made by JerosGamer89.
Used Inkscape, GIMP and Adobe Illustrator.
Animated icon with PowerDirector.


//   FILES INFO   //

SVGs are used for making vector images, which aren't made from pixels, but vectors based on maths, so they can be "zoomed" without loosing resolution. In the other hand PNGs are used for images, logotypes and transparent images, as it includes a new property in the RGB color system, the Alpha property, so it becomes RGBA.

Use SVGs to edit the assets, and PNGs for the final result, in the website or wherever, but I wouldn't recommend using the SVGs, unless you wanna make a CSS animation using an .svg image.

The GIF is for the animated icon for the server, or just as an animated icon.
In the MP4 folder you will find the original video of the animated icon, on it's original resolution (1080x1080) (1:1).


//  ASSETS INFO  //

Main colours:
- #2a7fff (light blue)
- #3737c8 (blurple)